#include<stdio.h>

int sum( int x, int y ) { return x + y; }
int sub( int x, int y ) { return x - y; }
int mul( int x, int y ) { return x * y; }

// Polymorpic Function
int calculator( int x, int y, int (*operation)(int, int )) {
	return operation( x, y );
}

int main() {
	int x = 40, y = 20, result = 0;

	result = calculator(x, y, sum);
	printf("\nResult : %d", result);

	result = calculator(x, y, sub);
	printf("\nResult : %d", result);

	result = calculator(x, y, mul);
	printf("\nResult : %d", result);
}
