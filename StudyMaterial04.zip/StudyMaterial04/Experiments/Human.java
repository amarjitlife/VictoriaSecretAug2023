
interface Superpower {
	void fly();
	void saveWorld();
}

class Spiderman implements Superpower {
	public void fly() 		 { System.out.println("Fly Like Spiderman!!!"); }
	public void saveWorld() { System.out.println("Save World Like Spiderman!!!"); }	
}

class Superman implements Superpower {
	public void fly() 		 { System.out.println("Fly Like Superman!!!"); }
	public void saveWorld() { System.out.println("Save World Like Superman!!!"); }	
}

class Heman {
	void fly() 		 { System.out.println("Fly Like Heman!!!"); }
	void saveWorld() { System.out.println("Save World Like Heman!!!"); }	
}

class HanumanJi implements Superpower {
	public void fly() 		 { System.out.println("Fly Like HanumanJi!!!"); }
	public void saveWorld() { System.out.println("Save World Like HanumanJi!!!"); }	
}

class Wonderwoman {
	void fly() 		 { System.out.println("Fly Like Wonderwoman!!!"); }
	void saveWorld() { System.out.println("Save World Like Wonderwoman!!!"); }	
}

// class Human extends Spiderman {
// class Human extends Superman {
// class Human extends Heman {
class Human extends Wonderwoman {
	void fly() 		 { super.fly(); }
	void saveWorld() { super.saveWorld(); }
}

class HumanAgain {
	// Spiderman power = new Spiderman();
	Superman power = new Superman();

	void fly() 		 { power.fly(); }
	void saveWorld() { power.saveWorld(); }
}

class HumanOnceAgain {
	// Spiderman power = new Spiderman();
	Superpower power = null;

	void fly() 		 { if ( power != null ) power.fly(); }
	void saveWorld() { if ( power != null ) power.saveWorld(); }
}

class HumanDemo {
	public static void main( String [] args ) {
		Spiderman spider = new Spiderman();
		spider.fly();
		spider.saveWorld();

		Human veeru = new Human();
		veeru.fly();
		veeru.saveWorld();

		HumanAgain veeruAgain = new HumanAgain();
		veeruAgain.fly();
		veeruAgain.saveWorld();

		HumanOnceAgain veeruOnceAgain = new HumanOnceAgain();
		veeruOnceAgain.power = new Spiderman();
		veeruOnceAgain.fly();
		veeruOnceAgain.saveWorld();		

		veeruOnceAgain.power = new Superman();
		veeruOnceAgain.fly();
		veeruOnceAgain.saveWorld();		

		veeruOnceAgain.power = new HanumanJi();
		veeruOnceAgain.fly();
		veeruOnceAgain.saveWorld();		
	}
}

