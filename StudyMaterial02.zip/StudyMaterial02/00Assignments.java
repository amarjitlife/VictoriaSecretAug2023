__________________________________________________________________

DAY 01
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Commands From First 95 Pages 

		Reference: Linux Pocket Guide, Oreilly Publication
				By Daniel J Barret

__________________________________________________________________

DAY 02
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Git Commands  
		Reference:
			GitBasicsTutorial.pdf

	Assignment A2: Reading and Experimentation Assignment
		Read and Experiment Additional Commands and Discover

		Reference: 
			Linux Pocket Guide, Oreilly Publication
				By Daniel J Barret
			Running Linux, Oreilly Publication

__________________________________________________________________

DAY 03
__________________________________________________________________


__________________________________________________________________

DAY 04
__________________________________________________________________


__________________________________________________________________

DAY 05
__________________________________________________________________


