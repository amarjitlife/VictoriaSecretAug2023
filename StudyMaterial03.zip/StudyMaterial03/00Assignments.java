__________________________________________________________________

DAY 01
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Commands From First 95 Pages 

		Reference: Linux Pocket Guide, Oreilly Publication
				By Daniel J Barret

__________________________________________________________________

DAY 02
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Git Commands  

		GitBasicsTutorial.pdf

__________________________________________________________________

DAY 03
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Git Commands  

		GitBranchingNotes.pdf

__________________________________________________________________

DAY 04
__________________________________________________________________


__________________________________________________________________

DAY 05
__________________________________________________________________


