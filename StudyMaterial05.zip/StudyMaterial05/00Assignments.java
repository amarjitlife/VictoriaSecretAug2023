__________________________________________________________________

DAY 01
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Commands From First 95 Pages 

		Reference: Linux Pocket Guide, Oreilly Publication
				By Daniel J Barret

__________________________________________________________________

DAY 02
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Git Commands  

		GitBasicsTutorial.pdf

__________________________________________________________________

DAY 03
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Git Commands  

		GitBranchingNotes.pdf

__________________________________________________________________

DAY 04
__________________________________________________________________

	Assignment A1: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In Java
			Chapter 1: Object-Oriented Design
			Chapter 2: Designing Classes with a Single Responsibility

		Reference Book:
			Practical Object-Oriented Design: An Agile Primer
				By Sandi Metz

	Assignment A2: Reading and Experimentation Assignment
		Read and Experiment Git Commands For Work Flow

		Reference Notes:
			GitBranchingNotes.pdf
			GitBranchingModelNotes.pdf
			GitFundamentalsNotes.pdf
			GitOnServerNotes.pdf

		Reference Links:
			https://nvie.com/posts/a-successful-git-branching-model/
			https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow

__________________________________________________________________

DAY 05 + SUNDAY
__________________________________________________________________

	// NOTE NOTE: Assignment A1 and Assignment A2 Are COMPULSORY
	Assignment A1: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In C
			Chapter 02: Types, Operators and Expressions
			Chapter 05: Pointers And Arrays

		Reference Book:
			The C Programming Language, 2nd Edition
				Brain Kernigham and Dennis Ritchie

	Assignment A2: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In Java
			Chapter 1: Object-Oriented Design
			Chapter 2: Designing Classes with a Single Responsibility
			Chapter 3: Managing Dependencies
			Chapter 4: Creating Flexible Interfaces 

		Reference Book:
			Practical Object-Oriented Design: An Agile Primer
				By Sandi Metz

	Assignment A3: Reading UML Diagrams
		Reference Links:
			https://www.visual-paradigm.com/guide/uml-unified-modeling-language/uml-class-diagram-tutorial/
			https://www.lucidchart.com/pages/uml-sequence-diagram
			https://creately.com/guides/sequence-diagram-tutorial/
			https://developer.ibm.com/articles/the-sequence-diagram/


__________________________________________________________________
__________________________________________________________________
__________________________________________________________________

